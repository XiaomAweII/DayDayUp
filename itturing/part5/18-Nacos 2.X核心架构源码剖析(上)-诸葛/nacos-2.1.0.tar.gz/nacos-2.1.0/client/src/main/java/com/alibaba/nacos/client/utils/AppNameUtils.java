/*
 * Copyright 1999-2018 Alibaba Group Holding Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.alibaba.nacos.client.utils;

import com.alibaba.nacos.client.constant.Constants;
import com.alibaba.nacos.common.utils.StringUtils;

import java.io.File;

/**
 * appName util.
 *
 * @author Nacos
 */
public class AppNameUtils {
    
    private static final String PARAM_MARKING_JBOSS = "jboss.server.home.dir";
    
    private static final String PARAM_MARKING_JETTY = "jetty.home";
    
    private static final String PARAM_MARKING_TOMCAT = "catalina.base";
    
    private static final String LINUX_ADMIN_HOME = "/home/admin/";
    
    private static final String SERVER_JBOSS = "jboss";
    
    private static final String SERVER_JETTY = "jetty";
    
    private static final String SERVER_TOMCAT = "tomcat";
    
    private static final String SERVER_UNKNOWN = "unknown server";
    
    private static final String DEFAULT_APP_NAME = "unknown";
    
    public static String getAppName() {
        String appName;
        
        appName = getAppNameByProjectName();
        if (appName != null) {
            return appName;
        }
        
        appName = getAppNameByServerHome();
        if (appName != null) {
            return appName;
        }
        
        return DEFAULT_APP_NAME;
    }
    
    private static String getAppNameByProjectName() {
        return System.getProperty(Constants.SysEnv.PROJECT_NAME);
    }
    
    private static String getAppNameByServerHome() {
        String serverHome = null;
        if (SERVER_JBOSS.equals(getServerType())) {
            serverHome = System.getProperty(PARAM_MARKING_JBOSS);
        } else if (SERVER_JETTY.equals(getServerType())) {
            serverHome = System.getProperty(PARAM_MARKING_JETTY);
        } else if (SERVER_TOMCAT.equals(getServerType())) {
            serverHome = System.getProperty(PARAM_MARKING_TOMCAT);
        }
        
        if (serverHome != null && serverHome.startsWith(LINUX_ADMIN_HOME)) {
            return StringUtils.substringBetween(serverHome, LINUX_ADMIN_HOME, File.separator);
        }
        
        return null;
    }
    
    private static String getServerType() {
        String serverType;
        if (System.getProperty(PARAM_MARKING_JBOSS) != null) {
            serverType = SERVER_JBOSS;
        } else if (System.getProperty(PARAM_MARKING_JETTY) != null) {
            serverType = SERVER_JETTY;
        } else if (System.getProperty(PARAM_MARKING_TOMCAT) != null) {
            serverType = SERVER_TOMCAT;
        } else {
            serverType = SERVER_UNKNOWN;
        }
        return serverType;
    }
    
}
